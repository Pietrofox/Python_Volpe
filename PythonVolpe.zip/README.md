# Python_intro
python of Russo by Pietro Volpe
per runnare il file digitare su shell "python nomefile.py"